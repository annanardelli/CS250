package edu.monmouth.cs250.s1164308.metriccalc

enum class Units {
    Temperature,
    Length,
    Mass,
    Volume
}