package edu.monmouth.cs250.s1164308.vacationspots.ui.dashboard

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import edu.monmouth.cs250.s1164308.vacationspots.Location
import edu.monmouth.cs250.s1164308.vacationspots.R
import edu.monmouth.cs250.s1164308.vacationspots.ui.filter.MyLocations


// class ListCustomAdapter(private val context: Context, itemViewListener: AdapterView.OnItemClickListener) : RecyclerView.Adapter <CustomViewHolder> () {
class ListCustomAdapter(private val context: Context, itemViewListener: CustomViewHolder.OnItemClickListener) : RecyclerView.Adapter <CustomViewHolder> () {

    var itemViewListener : CustomViewHolder.OnItemClickListener
    private var locationList = mutableListOf<Location> ()

    // intializer method - get the data from Student model class
    // Note - we are invoking the companion object using class reference Student.getStudentssFromFrom(...)
    init {
        this.itemViewListener = itemViewListener
        locationList = MyLocations.myFilteredLocations

    }
    // number of items in RecyclerView

    override fun getItemCount(): Int {
        // return pumpList.count()
        return locationList.count()
    }

    // create a viewHolder for the view

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        val locationItemLayout = LayoutInflater.from(parent.context)
        val locationItemView = locationItemLayout.inflate(R.layout.location_item, parent, false)
        return CustomViewHolder(locationItemView)
    }


    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {

        val location = locationList.get(position)
        // holder.bind(location, context, itemViewListener)
        holder.bind(location, context, itemViewListener)
        val selectedLocation: String = "selectedLocation"
        val bundle = Bundle().apply {
            putParcelable(selectedLocation, location)
        }

        holder.itemView.setOnClickListener {
            Navigation.findNavController(holder.itemView).navigate(R.id.action_navigation_dashboard_to_navigation_location_detail, bundle)
            //  Navigation.findNavController(holder.itemView).navigate(R.id.action_navigation_dashboard_to_locationDetails, bundle)
        }
    }



}
// setup the data viewHolder view.
// Image loaded using Glide image library
// Also the clickListner.

class CustomViewHolder (itemView: View): RecyclerView.ViewHolder (itemView) {
    // variables to access the views in Activity Adapter
    var titleTextView: TextView = itemView.findViewById<TextView>(R.id.LocationName)
    var descTextView: TextView = itemView.findViewById<TextView>(R.id.LocationCountry)
    var stationImage: ImageView = itemView.findViewById<ImageView>(R.id.locationPhoto)

    // bind data to view
    // Also onClickListner as a lambda

    // fun bind(location: Location, context: Context, itemViewListener: OnItemClickListener) {
    fun bind(location: Location, context: Context, itemViewListener: OnItemClickListener) {
        itemView.setOnClickListener {
            itemViewListener.onViewItemClicked(location)

        }

        titleTextView.text = location.city
        descTextView.text = location.country


        val imageName = location.locid
        val imageID = context.resources.getIdentifier(imageName, "drawable", context.packageName)
        stationImage.setImageResource(imageID)
    }

    interface OnItemClickListener {
        fun onViewItemClicked(location: Location)
    }
}