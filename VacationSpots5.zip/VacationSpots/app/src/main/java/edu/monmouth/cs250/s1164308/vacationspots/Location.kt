package edu.monmouth.cs250.s1164308.vacationspots

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import org.json.JSONArray
import org.json.JSONException

class Location(
    val cid: Int, val longitude: Double, val latitude: Double, val city: String?,
    val country: String?, val climate: String?, val region: String?, val beach: Boolean,
    val hiking: Boolean, val urban: Boolean, val language: String?, val themePark: Boolean, val withinUS: Boolean,
    val locid: String?
): Parcelable {
    companion object CREATOR : Parcelable.Creator<Location> {
        fun getLocationsFromFile(filename: String, context: Context?): MutableList<Location> {
            val locations = mutableListOf<Location>()

            try {
                // Load data
                val jsonString = loadJsonFromAsset(filename, context)
                if (jsonString != null) {
                    // val json = JSONObject(jsonString)  // decode JSON Sting to an key-value pair map

                    val locationJSONarray = JSONArray(jsonString)

                    // Get Location objects from data
                    (0 until locationJSONarray.length()).mapTo(locations) {
                        Location(
                            locationJSONarray.getJSONObject(it).getInt("CID"),
                            locationJSONarray.getJSONObject(it).getDouble("LONGITUDE"),
                            locationJSONarray.getJSONObject(it).getDouble("LATITUDE"),
                            locationJSONarray.getJSONObject(it).getString("CITY"),
                            locationJSONarray.getJSONObject(it).getString("COUNTRY"),
                            locationJSONarray.getJSONObject(it).getString("CLIMATE"),
                            locationJSONarray.getJSONObject(it).getString("REGION"),
                            locationJSONarray.getJSONObject(it).getBoolean("BEACH"),
                            locationJSONarray.getJSONObject(it).getBoolean("HIKING"),
                            locationJSONarray.getJSONObject(it).getBoolean("URBAN"),
                            locationJSONarray.getJSONObject(it).getString("PRIMARY_LANGUAGE"),
                            locationJSONarray.getJSONObject(it).getBoolean("THEME_PARK"),
                            locationJSONarray.getJSONObject(it).getBoolean("WITHIN_US"),
                            locationJSONarray.getJSONObject(it).getString("LOCID")
                        )
                    }

                } else {
                    println("not a valid JSON string")
                }


            } catch (e: JSONException) {
                e.printStackTrace()
            }

            return locations
        }

        override fun createFromParcel(parcel: Parcel): Location {
            return Location(parcel)
        }

        override fun newArray(size: Int): Array<Location?> {
            return arrayOfNulls(size)
        }

        // open file and read all characters into a buffer. Convert buffer to String

        private fun loadJsonFromAsset(filename: String, context: Context?): String? {
            var json: String?


            try {
                val inputStream = context!!.assets.open(filename)
                val size = inputStream.available()
                val buffer = ByteArray(size)

                inputStream.read(buffer)
                inputStream.close()
                val charset = Charsets.UTF_8

                json = buffer.toString(charset)


            } catch (ex: java.io.IOException) {
                ex.printStackTrace()
                return null
            }

            return json
        }
    }

    constructor(parcel: Parcel) : this(
        cid = parcel.readInt(),
        longitude = parcel.readDouble(),
        latitude = parcel.readDouble(),
        city = parcel.readString(),
        country = parcel.readString(),
        climate = parcel.readString(),
        region = parcel.readString(),
        beach = parcel.readBoolean(),
        hiking = parcel.readBoolean(),
        urban = parcel.readBoolean(),
        language = parcel.readString(),
        themePark = parcel.readBoolean(),
        withinUS = parcel.readBoolean(),
        locid = parcel.readString()
    )

    override fun describeContents(): Int {
        TODO("Not yet implemented")
    }

    override fun writeToParcel(p0: Parcel?, p1: Int) {
        TODO("Not yet implemented")
    }


}