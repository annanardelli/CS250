package edu.monmouth.cs250.s1164308.vacationspots.ui.map

import androidx.fragment.app.Fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import edu.monmouth.cs250.s1164308.vacationspots.Location
import edu.monmouth.cs250.s1164308.vacationspots.R
import edu.monmouth.cs250.s1164308.vacationspots.ui.filter.MyLocations
import kotlin.math.round

class MapsFragment : Fragment() {

    private var locations = mutableListOf<Location>()
    private lateinit var mMap: GoogleMap

    private val callback = OnMapReadyCallback { googleMap ->

        var zoomLevel = 4.0f
        val monmouth = LatLng(40.28049677217607, -74.00541140204132)

        val mapSettings = googleMap.uiSettings
        mapSettings.isZoomControlsEnabled = true
        mapSettings.isMapToolbarEnabled = true
        mapSettings.isCompassEnabled = true

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(monmouth, zoomLevel))

        locations = MyLocations.myFilteredLocations
        showLocations(googleMap, locations)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_maps, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }

    private fun showLocations(mMap: GoogleMap, list1: MutableList<Location>) {
        for (location in list1) {
            val locationLatLng = LatLng(location.latitude, location.longitude)

            location.city?.let { Log.i("Main Activity", it) }

            var marker = mMap.addMarker(
                MarkerOptions().position(locationLatLng).title(location.city)
                    .icon(
                        BitmapDescriptorFactory
                            .defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
                    )
            )
            if (marker != null) {
                marker.tag = location.cid
            }
        }
    }
}