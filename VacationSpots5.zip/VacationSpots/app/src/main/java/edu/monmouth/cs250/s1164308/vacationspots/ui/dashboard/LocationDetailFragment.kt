package edu.monmouth.cs250.s1164308.vacationspots.ui.dashboard

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import edu.monmouth.cs250.s1164308.vacationspots.Location
import edu.monmouth.cs250.s1164308.vacationspots.databinding.FragmentLocationDetailBinding

class LocationDetailFragment : Fragment() {

    private var _binding:FragmentLocationDetailBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentLocationDetailBinding.inflate(inflater, container, false)
        val root:View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val selectedLocation:String = "selectedLocation"


        val thisLocation = this.arguments?.getParcelable<Location>(selectedLocation)

        //  val rID = resources.getIdentifier()
        val resID = resources.getIdentifier(
            thisLocation?.locid.toString(),
            "drawable", context?.packageName
        )
        Log.i("Details Framgment", resID.toString())
        binding.cityImage.setImageResource(resID)
        Log.i("Details Fragment: ", thisLocation?.city.toString())
        binding.city.text = thisLocation?.city.toString()
        binding.country.text = thisLocation?.country.toString()
        binding.region.text = thisLocation?.region.toString()
        binding.climate.text = thisLocation?.climate.toString()

        if (thisLocation?.beach == true) {
            binding.beachSwitch.isChecked = true
        }
        if (thisLocation?.urban == true) {
            binding.urbanSwitch.isChecked = true
        }
        if (thisLocation?.hiking == true) {
            binding.hikingSwitch.isChecked = true
        }
    }

}