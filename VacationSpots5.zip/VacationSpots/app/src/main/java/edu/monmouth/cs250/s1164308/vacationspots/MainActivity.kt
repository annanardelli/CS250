package edu.monmouth.cs250.s1164308.vacationspots

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.Spinner
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import edu.monmouth.cs250.s1164308.vacationspots.databinding.ActivityMainBinding
import edu.monmouth.cs250.s1164308.vacationspots.ui.dashboard.CustomViewHolder
import edu.monmouth.cs250.s1164308.vacationspots.ui.dashboard.LocationDetailFragment
import edu.monmouth.cs250.s1164308.vacationspots.ui.filter.MyLocations

class MainActivity : AppCompatActivity(), CustomViewHolder.OnItemClickListener, AdapterView.OnItemSelectedListener {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_map
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        MyLocations.initLocations(this)
    }


    override fun onViewItemClicked(location: Location) {
        val bundle = Bundle()
        bundle.putInt("CID", location.cid)
        Log.i("Main Activity", "Fragment to Fragment Transition")

        val transaction = this.supportFragmentManager.beginTransaction()
        // val frag2 = LocationDetails()
        val frag2 = LocationDetailFragment()

        frag2.arguments = bundle

        transaction.replace(R.id.nav_view, frag2)
        transaction.addToBackStack(null)
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
        transaction.commit()
    }

    override fun onItemSelected(arg0: AdapterView<*>, arg1: View, position: Int, id: Long) {
        //use position to know the selected item
        MyLocations.setClimateMode(Climates.values()[position])
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}