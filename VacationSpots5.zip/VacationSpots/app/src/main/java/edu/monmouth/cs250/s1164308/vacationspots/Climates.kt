package edu.monmouth.cs250.s1164308.vacationspots

enum class Climates {
    None,
    Temperate,
    Tropical,
    Mediterranean,
    Subtropical,
    Continental,
    Subarctic,
    Arid,
    Maritime,
    SemiArid
}