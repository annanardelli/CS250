package edu.monmouth.cs250.s1164308.vacationspots

enum class Languages {
    None,
    French,
    English,
    Italian,
    Thai,
    Japanese,
    Spanish,
    Dhivehi,
    BahsaIndonesia,
    Arabic,
    Greek,
    Dutch,
    Swahili,
    German,
    Danish,
    Croatian
}