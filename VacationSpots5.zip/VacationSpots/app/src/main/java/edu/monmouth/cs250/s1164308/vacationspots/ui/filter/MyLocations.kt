package edu.monmouth.cs250.s1164308.vacationspots.ui.filter

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import edu.monmouth.cs250.s1164308.vacationspots.Climates
import edu.monmouth.cs250.s1164308.vacationspots.Climates.*
import edu.monmouth.cs250.s1164308.vacationspots.Languages
import edu.monmouth.cs250.s1164308.vacationspots.Languages.*
import edu.monmouth.cs250.s1164308.vacationspots.Location

@SuppressLint("StaticFieldLeak")
object MyLocations {
    private lateinit var context: Context

    private var climateMode: Climates = SemiArid
    private var languageMode: Languages = BahsaIndonesia

    var locations = mutableListOf<Location>()
    var myFilteredLocations =  mutableListOf<Location>()

    fun initLocations(context: Context) {
        this.context = context
        this.locations = Location.getLocationsFromFile("locations.json", context)
        this.myFilteredLocations = this.locations.toMutableList()
        Log.i("Singleton", locations.size.toString())
    }
//fun setFilterdLocations(isBeach: Boolean, isUS: Boolean, isHiking: Boolean, isThemePark: Boolean, lang: Languages, clim: Climates)
    fun setFilterdLocations(isBeach: Boolean, isUS: Boolean, isHiking: Boolean, isThemePark: Boolean) {

        myFilteredLocations = this.locations.filter{it.withinUS == isUS}.toMutableList()
        myFilteredLocations = myFilteredLocations.filter{it.beach == isBeach}.toMutableList()
        myFilteredLocations = myFilteredLocations.filter{it.hiking == isHiking}.toMutableList()
        myFilteredLocations = myFilteredLocations.filter{it.themePark == isThemePark}.toMutableList()

    /**
        when(lang){
            Languages.None -> myFilteredLocations
            Arabic -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Arabic) }.toMutableList()
            BahsaIndonesia -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(BahsaIndonesia) }.toMutableList()
            Croatian -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Croatian) }.toMutableList()
            Danish -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Danish) }.toMutableList()
            Dhivehi -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Dhivehi)}.toMutableList()
            Dutch -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Dutch) }.toMutableList()
            English -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(English) }.toMutableList()
            French-> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(French) }.toMutableList()
            German -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(German) }.toMutableList()
            Greek -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Greek) }.toMutableList()
            Italian -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Italian) }.toMutableList()
            Japanese -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Japanese) }.toMutableList()
            Spanish -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Spanish) }.toMutableList()
            Swahili -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Swahili) }.toMutableList()
            Thai -> myFilteredLocations = myFilteredLocations.filter{it.language!!.equals(Thai) }.toMutableList()
        }

        when(clim) {
            Climates.None -> myFilteredLocations
            Arid -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Arid) }.toMutableList()
            Continental -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Continental) }.toMutableList()
            Maritime -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Maritime) }.toMutableList()
            Mediterranean -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Mediterranean) }.toMutableList()
            SemiArid -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(SemiArid) }.toMutableList()
            Subarctic -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Subarctic) }.toMutableList()
            Subtropical -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Subtropical) }.toMutableList()
            Temperate -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Temperate) }.toMutableList()
            Tropical -> myFilteredLocations = myFilteredLocations.filter{it.climate!!.equals(Tropical) }.toMutableList()
        }
**/
       fun getFilteredLocations(): MutableList<Location> {
           return this.myFilteredLocations
       }
    }

    public fun setClimateMode (selectedMode: Climates) {
        climateMode = selectedMode
    }

    public fun getClimateMode(): Climates {
        return climateMode
    }


    // implement getters and setting for filter variables

}