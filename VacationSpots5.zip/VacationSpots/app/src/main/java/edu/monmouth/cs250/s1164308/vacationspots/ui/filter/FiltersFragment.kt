package edu.monmouth.cs250.s1164308.vacationspots.ui.filter

import android.R
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import edu.monmouth.cs250.s1164308.vacationspots.Climates
import edu.monmouth.cs250.s1164308.vacationspots.Location
import edu.monmouth.cs250.s1164308.vacationspots.databinding.FragmentFiltersBinding


class FiltersFragment : Fragment() {
    private var _binding: FragmentFiltersBinding? = null
    private var climateMode: Climates = Climates.SemiArid
    private val binding get() = _binding!!

    var languages = ArrayList<String>()
    var climates = ArrayList<String>()
    var locations = mutableListOf<Location>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFiltersBinding.inflate(inflater, container, false)
        // return super.onCreateView(inflater, container, savedInstanceState)
        val root = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        locations = MyLocations.myFilteredLocations
/**
        for (language in Languages.values()) {
            languages.add(language.name)
        }
        //binding.languageSpinner.setOnItemSelectedListener(this)

        //create an ArrayAdapter to hold dropdown items
        val aa = activity?.let { ArrayAdapter(it, android.R.layout.simple_spinner_item, languages) }
        //set layout to use when the list of choices appear
        aa?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        //set Adapter to Spinner
        binding.languageSpinner.setAdapter(aa)
**/
        for (climate in Climates.values()) {
            climates.add(climate.name)
        }
        // binding.climateSpinner.setOnItemSelectedListener(this)

        //create an ArrayAdapter to hold dropdown items
        val aa2 = activity?.let { ArrayAdapter(it, R.layout.simple_spinner_item, climates) }
        //set layout to use when the list of choices appear
        aa2?.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
        //set Adapter to Spinner
        binding.climateSpinner.setAdapter(aa2)

        binding.filterButton.setOnClickListener {

            MyLocations.setFilterdLocations(
                binding.beachFilter.isChecked,
                binding.withinUSFilter.isChecked,
                binding.hikingFilter.isChecked,
                binding.themeParkFilter.isChecked,
                //MyLocations.getClimateMode()


            )
        }
    }


    }





//init:: get locations from file
//update filters method
//get filters method
