package edu.monmouth.cs250.s1164308.cs250

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.student_item.view.*

class StudentDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_detail)


    }

    companion object {
        const val EXTRA_TITLE = "name"
        fun newIntent(context: Context, student: Student): Intent {
            val detailIntent = Intent(context, StudentDetail::class.java)
            detailIntent.putExtra(EXTRA_TITLE, student.studentName)
            return detailIntent
        }
    }
}