package edu.monmouth.cs250.s1164308.cs250

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), OnItemClickListener {
    lateinit var customAdapter: StudentListCustomAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        studentListView.layoutManager = LinearLayoutManager(this)
        customAdapter = StudentListCustomAdapter(this, this)
        studentListView.adapter = customAdapter
    }

    override fun onViewItemClicked(student: Student) {
        val detailIntent = StudentDetail.newIntent(this, student)
        startActivity(detailIntent)
    }

}