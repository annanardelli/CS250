package edu.monmouth.cs250.s1164308.cs250

import android.content.Context
import org.json.JSONException
import org.json.JSONObject

class Student (

    val studentName: String,
    val ID: Int,
    val email: String,
    val major: String,
    val sClass: Int,
    val advisor: String,
    val credits: Int,
    val status: String)

{

    companion object {

        fun getStudentsFromFile(fileName: String, context: Context): ArrayList<Student>{
            val studentList = ArrayList<Student>()

            try {
                // Load data
                val jsonString = loadJsonFromAsset(fileName, context)
                if (jsonString != null) {
                    val json = JSONObject(jsonString)  // decode JSON Sting to an key-value pair map
                    val students = json.getJSONArray("cs250Students")

                    // Get Student objects from data
                    (0 until students.length()).mapTo(studentList) {
                        Student(students.getJSONObject(it).getString("Student Name"),
                            students.getJSONObject(it).getInt("ID"),
                            students.getJSONObject(it).getString("Email"),
                            students.getJSONObject(it).getString("Major"),
                            students.getJSONObject(it).getInt("Class"),
                            students.getJSONObject(it).getString("Advisor"),
                            students.getJSONObject(it).getInt("Credits"),
                            students.getJSONObject(it).getString("Admit Status")) }
                } else {
                    println ("not a valid JSON string")
                }



            } catch (e: JSONException) {
                e.printStackTrace()
            }

            return studentList
        }

        private fun loadJsonFromAsset(fileName: String, context: Context): String? {
            var jsonString: String?


            try {
                val inputStream = context.assets.open(fileName)
                val size = inputStream.available()
                val buffer = ByteArray(size)

                inputStream.read(buffer)
                inputStream.close()
                val charset = Charsets.UTF_8

                jsonString = buffer.toString(charset)


            } catch (ex: java.io.IOException) {
                ex.printStackTrace()
                return null
            }

            return jsonString
        }
    }



}